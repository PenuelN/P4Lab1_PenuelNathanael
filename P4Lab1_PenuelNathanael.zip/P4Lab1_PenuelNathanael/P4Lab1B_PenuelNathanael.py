import turtle

# Set up
t = turtle.Turtle()
t.pensize(5)  # Set pen size
t.pencolor("blue")  # Set pen color

# Draw first initial
t.penup()
t.goto(-50, 0)
t.pendown()
t.left(90)
t.forward(100)
t.right(135)
t.forward(140)
t.left(135)
t.forward(100)

# Move to position for second initial
t.penup()
t.goto(50, 0)
t.pendown()

# Draw second initial
t.left(90)
t.forward(100)
t.right(90)
t.forward(50)
t.right(90)
t.forward(50)
t.right(90)
t.forward(50)

# End
turtle.done()
