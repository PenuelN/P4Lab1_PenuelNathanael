import turtle

# Set up
t = turtle.Turtle()
t.speed(1)  # Control the speed of the drawing (1 is slow, 10 is fast)

# Draw a square
for _ in range(4):
    t.forward(100)  # Move forward by 100 units
    t.right(90)     # Turn right by 90 degrees

# Position
t.penup()
t.goto(-50, 50)  # Adjust this position as needed
t.pendown()

# Draw a triangle
for _ in range(3):
    t.forward(100)  # Move forward by 100 units
    t.left(120)     # Turn left by 120 degrees

# End
turtle.done()
